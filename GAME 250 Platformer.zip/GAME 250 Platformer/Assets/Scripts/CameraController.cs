﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{

    public Transform target;

    public Vector3 offset;

    public bool useoffsetvalues;

    public float rotateSpeed;

    public Transform pivot;


    public float maxViewAngle;
    public float minViewAngle;


    // Start is called before the first frame update
    void Start()
    {
        if (!useoffsetvalues)
        {
            offset = target.position - transform.position;
            Cursor.lockState = CursorLockMode.Locked;
        }


        pivot.transform.position = target.transform.position;
        pivot.transform.parent = target.transform;
        
    }

    // Update is called once per frame
    void LateUpdate()
    {
        //move the x posistion of mouse and rotat the target
        float horiziontal = Input.GetAxis("Mouse X") * rotateSpeed;
        target.Rotate(0, horiziontal, 0);


        //get y position of the mouse and rotate the pivot        
        float vertical = Input.GetAxis("Mouse Y") * rotateSpeed;
        pivot.Rotate(-vertical, 0, 0);


        //Limit up/down camera rotation
        if (pivot.rotation.eulerAngles.x > maxViewAngle && pivot.rotation.eulerAngles.x < 180f)
        {
            pivot.rotation = Quaternion.Euler(maxViewAngle, 0, 0);
        }

        if(pivot.rotation.eulerAngles.x > 100f && pivot.rotation.eulerAngles.x < 350f + minViewAngle)
        {
            pivot.rotation = Quaternion.Euler(315f, 0, 0);
        }

        //move the camera based on the current rotation of the target and the original offset
        float desireYdAngle = target.eulerAngles.y;
        float desireXdAngle = pivot.eulerAngles.x;

        Quaternion rotation = Quaternion.Euler(desireXdAngle, desireYdAngle, 0);
        transform.position = target.position - (rotation * offset);



       // transform.position = target.position - offset;
       if(transform.position.y < target.position.y)
        {
            transform.position = new Vector3(transform.position.x, target.position.y - 5f, transform.position.z);
        }

        transform.LookAt(target);
    }
}
