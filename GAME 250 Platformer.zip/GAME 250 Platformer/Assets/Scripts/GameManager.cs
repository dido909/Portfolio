﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameManager : MonoBehaviour
{



    public int currentGold;
    public Text goldText;


    public void RemainingGold(int goldLeft)
    {
        currentGold -= goldLeft;
        goldText.text = "GOLD: " + currentGold; 
        if(currentGold <= 0)
        {
            Cursor.lockState = CursorLockMode.None;
            SceneManager.LoadScene("WIN");
        }
    }
}
