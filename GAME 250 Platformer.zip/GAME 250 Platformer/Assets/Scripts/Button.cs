﻿using UnityEngine.SceneManagement;
using UnityEngine;

public class Button : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene("Platformer");
    }
    public void QuitGame()
    {
        Application.Quit();
    }
}
